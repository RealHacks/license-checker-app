
# 🧾 License-Checker Desktop App

This project demonstrates how to create a desktop application that checks for a license key online before launching.

## 🌐 License Server (Flask API)

### Setup

```bash
cd server
pip install -r requirements.txt
python license_server.py
```

To generate a license key:

```bash
python generate_license.py
```

## 💻 Client Desktop App

### Run the app

```bash
cd client
pip install -r requirements.txt
python main.py
```

### Package with PyInstaller

```bash
pyinstaller --onefile main.py
```

Output binary will be in `dist/`.

## 🚀 Deployment

Deploy `server/license_server.py` to Render.com or any other cloud provider.
